<?php

for ($contador = 1; $contador <= 15; $contador++) {
    echo "#$contador" . PHP_EOL;
}
